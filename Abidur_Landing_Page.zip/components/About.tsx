import React from "react";
import { motion } from "framer-motion";

const About = () => {
  return (
    <section className="py-20 px-6 md:px-20 bg-white">
      <motion.h2
        className="text-3xl font-bold text-center mb-8"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
      >
        About Me
      </motion.h2>
      <motion.p
        className="text-lg max-w-3xl mx-auto text-center text-gray-700 leading-relaxed"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        I am a dedicated and detail-oriented Virtual Assistant with over 10 years of experience in helping businesses streamline workflows, boost productivity, and execute projects seamlessly. My expertise spans Virtual Assistance, Social Media Management, E-Commerce Management, Project Management, WordPress development, and AI prompt engineering. I thrive on delivering reliable, timely, and professional results that help my clients focus on what truly matters—growing their business.
      </motion.p>
    </section>
  );
};

export default About;