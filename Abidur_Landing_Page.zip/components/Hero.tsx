import React from "react";
import { motion } from "framer-motion";

const Hero = () => {
  return (
    <section className="bg-gradient-to-r from-primary to-secondary text-white min-h-screen flex flex-col justify-center items-center text-center px-6">
      <motion.h1
        className="text-5xl md:text-6xl font-bold mb-4"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8 }}
      >
        Md. Abidur Rahman
      </motion.h1>
      <motion.p
        className="text-xl md:text-2xl mb-6"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.8 }}
      >
        Your Versatile Virtual Assistant & AI Specialist
      </motion.p>
      <motion.div
        className="flex gap-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6, duration: 0.8 }}
      >
        <a
          href="mailto:porosh.abidlaw@gmail.com"
          className="px-6 py-3 bg-accent rounded-lg font-semibold hover:bg-pink-400 transition"
        >
          Email Me
        </a>
        <a
          href="https://www.linkedin.com/in/rahman-abidur/"
          target="_blank"
          className="px-6 py-3 border-2 border-white rounded-lg font-semibold hover:bg-white hover:text-secondary transition"
        >
          LinkedIn
        </a>
      </motion.div>
    </section>
  );
};

export default Hero;